# -*- coding: utf-8 -*-
"""
emitplot.py

Plots data from a Dynac generated emit.plot file.  

Usage:
python emitplot.py [-f filename] [-s starting position]

filename: File to scan for plot data.  Default: "emit.plot"
starting postion: Position within the file, in bytes,
                        of the data to plot.  Default: 0
"""
from PyQt4.uic import loadUiType
from PyQt4 import QtGui
from matplotlib.figure import Figure
from matplotlib import rcParams
from matplotlib import pyplot as plt
from matplotlib import cm as cm
from matplotlib.backends.backend_qt4agg import(
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavigationToolbar)
import numpy as np
import sys
import getopt
import re
import os

Ui_MainWindowEmit, QMainWindowEmit = loadUiType('emitplot.ui')
Ui_MainWindowEnv, QMainWindowEnv = loadUiType('envplot.ui')

rcParams.update({'figure.autolayout': True})

class EmitPlot(QMainWindowEmit, Ui_MainWindowEmit):
    
    def __init__(self, plotData):
        # Code that fires when class is instantiated
        super(EmitPlot, self).__init__()
        self.setupUi(self)
        if plotData['graphtype'] in [1,6]:
            makeEmitPlot(self, plotData)
        else:
            print 'Unsupported graph type %s.' % plotData['graphtype']
            quit()
        
        self.actionBeam_Data.triggered.connect(self.beamData)
        self.actionWrite_dst_File.triggered.connect(self.writeDist)
    
    def beamData(self):
        if not plotData['dsdata']:
            self.statusbar.showMessage('No beam data available.')
            return
        msg = QtGui.QMessageBox()
        msg.setWindowTitle("Beam Data")
        bdtext = "Beam Data for Plot: %s\n\n" % plotData['title']
        bdtext += "Ref. Particle Energy: %g MeV\n" % float(plotData['energyrp'])
        bdtext += "Ref. Particle Beta: %s\n" % plotData['betarp']
        bdtext += "RF Freqeuncy: %s MHz\n\n" % plotData['freq']
        bdtext += 'X Axis:\n'
        bdtext += '   Alpha: %g\n' % float(plotData['alphax'])
        bdtext += '   Beta:  %g mm/mrad\n' % float(plotData['betax'])
        bdtext += '   Emittance (4 RMS): %s mm.mrad\n\n' % (
            float(plotData['emitxnon']))
        bdtext += 'Y Axis:\n'
        bdtext += '   Alpha: %g\n' % float(plotData['alphay'])
        bdtext += '   Beta:  %g mm/mrad\n' % float(plotData['betay'])
        bdtext += '   Emittance (4 RMS): %g mm.mrad\n\n' % (
            float(plotData['emitynon']))  
        bdtext += 'Z Axis:\n'
        bdtext += '   Emittance (4 RMS, non-normalized):\n'
        bdtext += '        %g keV.ns\n' % float(plotData['emitznk'])
        bdtext += '        %g keV.deg\n' % float(plotData['emitzdk'])
        bdtext += '   Phase 1/2 Width (4RMS): %s degrees\n' % (
            float(plotData['phiwidth']))
        bdtext += '   Energy 1/2 Width (4RMS): %s keV\n\n' % (
            float(plotData['ewidth']))
        bdtext += '   Number of Particles: %s' % plotData['nparticles'] 
        
        msg.setText(bdtext)
        msg.setStandardButtons(QtGui.QMessageBox.Ok)

        retval = msg.exec_()

    def writeDist(self):
	    # Write an output particle data file in Dynac *.dst format
        if not plotData['dsdata']:
            self.statusbar.showMessage('No beam data available.')
            return

        dstfilename = QtGui.QFileDialog.getSaveFileName() 
        if not dstfilename: # Handle 'cancel' in file select
            return

        if plotData['graphtype'] == 1:  
            # Ask user for charge state for single charge state beams 
            charge, ok = QtGui.QInputDialog.getInt(self, "Charge State Selection",
                "Enter Charge State:")
            if not ok:                  # Bail if user cancels
                return
            else:
                charges = np.full(len(plotData['x']),charge, np.double)
        else:                           # Multi charge state beams
            charges = plotData['xchg']
            
        # Convert units for output
        xp = plotData['xp'] * 10**(-3) # mrad -> rad
        yp = plotData['yp'] * 10**(-3) # mrad -> rad
        rads = plotData['deg'] * 2 * np.pi / 360.
        absenergy = plotData['relenergy'] + float(plotData['energyrp'])

        with open(dstfilename, 'w') as dst:
            # Header line
            dst.write('%12d   %18.16f    %22.15f  %22.15f\n' % (
                float(plotData['nparticles']),0,float(plotData['freq']),
                float(plotData['energyrp'])))
            for i in range(len(plotData['x'])):
                dst.write('%+12.6E %+12.6E %+12.6E %+12.6E %+12.6E %+12.6E %+12.6E\n' % (
                    plotData['x'][i], xp[i], plotData['y'][i], yp[i],
                    rads[i], absenergy[i], charges[i]))
        
        self.statusbar.showMessage('Beam distribution file %s written' %
            dstfilename)
                
    
    def closeEvent(self, event): # Solves crash on exit
        if __name__== '__main__':
            exit()


class EnvPlot(QMainWindowEnv, Ui_MainWindowEnv):
    
    def __init__(self, plotData):
        # Code that fires when class is instatntiated
        super(EnvPlot, self).__init__()
        self.setupUi(self)
        if plotData['graphtype'] in [3, 4, 5]:
            makeEnvPlot(self, plotData)
        else:
            print 'Unsupported graph type %s.' % plotData['graphtype']
            quit()
            
    def closeEvent(self, event): # Solves crash on exit
        if __name__ == '__main__':
            exit()


def makeEmitPlot(self, plotData):
    # Set up figures
    poslist = ['ul', 'ur', 'll', 'lr']
    self.panes = [self.ulPane, self.urPane, self.llPane, self.lrPane]
    figDict = {}
    self.titleLabel.setText(plotData['title'])
    for pos, pane in zip(poslist, self.panes):
        figDict[pos+"pane"] = pane
        figDict[pos+"fig"] = Figure()
        figDict[pos+"axis"] = figDict[pos+"fig"].add_subplot(111)
        figDict[pos+"canvas"] = FigureCanvas(figDict[pos+"fig"])
        figDict[pos+"pane"].addWidget(figDict[pos+"canvas"])
        figDict[pos+"canvas"].draw()
    
    # Set graph data
    plr = []
    lrtype = ['deg','rel']
    if plotData['graphtype'] == 1:  # Single Charge State Beam
        # Set figure data and properties
        # x x' plot
        figDict['ulaxis'].plot(plotData['x'], plotData['xp'], 'r.')
        # y y' plot
        figDict['uraxis'].plot(plotData['y'], plotData['yp'], 'r.')
        # x y plot
        figDict['llaxis'].plot(plotData['x'], plotData['y'], 'r.')
        # z z' plot
        h, = figDict['lraxis'].plot(plotData['deg'], plotData['relenergy'], 'r.')
        plr.append(h)
    else:                           # Multiple Charge State Beam
        colors = cm.rainbow(np.linspace(0, 1, plotData['nstates']))
        #urhandle = np.zeros(plotData['nstates'])
        plr = []
        for idx, state in enumerate(plotData['chgvals']):
            chindex = np.where(plotData['xchg'] == state)[0]
            figDict['ulaxis'].plot(plotData['x'][chindex], 
                plotData['xp'][chindex], color = colors[idx], 
                marker = '.', ls = 'none')
            figDict['uraxis'].plot(plotData['y'][chindex],
                plotData['yp'][chindex], color = colors[idx],
                marker = '.', ls = 'none', label = state)
            figDict['llaxis'].plot(plotData['x'][chindex],
                plotData['y'][chindex], color = colors[idx],
                marker = '.', ls = 'none')
            h, = figDict['lraxis'].plot(plotData['deg'][chindex],
                plotData['relenergy'][chindex], color = colors[idx],
                marker = '.', ls = 'none')
            plr.append(h)
        # Generate the legend
        figDict['uraxis'].legend(numpoints = 1, title = 'Chg. St.')
        
    # Plot ovals if generated
    if plotData['isoval']:
        figDict['ulaxis'].plot(plotData['xxpoval'][0],
            plotData['xxpoval'][1], 'k--')
        figDict['uraxis'].plot(plotData['yypoval'][0],
            plotData['yypoval'][1], 'k--')
        h, = figDict['lraxis'].plot(plotData['peoval'][0],
            plotData['peoval'][1], 'k--') 
        plr.append(h)
           
    # Setup Graph Appearance
    figDict['ulaxis'].set_xlabel('X [cm]')
    figDict['ulaxis'].set_ylabel('X\' [mrad]')
    figDict['uraxis'].set_xlabel('Y [cm]')
    figDict['uraxis'].set_ylabel('Y\' [mrad]')
    figDict['llaxis'].set_xlabel('X [cm]')
    figDict['llaxis'].set_ylabel('Y [cm]')
    figDict['lraxis'].set_xlabel('Phase [deg]')
    figDict['lraxis'].set_ylabel('Rel. Energy [MeV]') 
    figDict['lraxis'].ticklabel_format(style='sci', axis = 'x', scilimits=(-4,4))
    figDict['lraxis'].ticklabel_format(style='sci', axis = 'y', 
        scilimits=(-3,3), useOffset = False)
    
    # Set limits and allow for click to autoscale
    figDict['ulaxis'].set(xlim=plotData['xlim'],ylim=plotData['xplim'])
    figDict['uraxis'].set(xlim=plotData['ylim'],ylim=plotData['yplim'])
    figDict['llaxis'].set(xlim=plotData['xlim'],ylim=plotData['ylim'])
    figDict['lraxis'].set(xlim=plotData['plim'],ylim=plotData['elim'])   

    def showhist(self, choice):
        # Generate histograms on x/y and p/e axes
        def emithist(series):
            nbins = 30
            values, left = np.histogram(series, bins = nbins)
            binwidth = left[2] - left[1]
            centers = left + binwidth
            return [values, centers[0:len(centers) - 1]]
        
        if not choice == 'pe': # x / y histogram
            xhistValues, xhistCenters = emithist(plotData['x'])
            yhistValues, yhistCenters = emithist(plotData['y'])
            xlimits = figDict['llaxis'].get_xlim()
            ylimits = figDict['llaxis'].get_ylim()
            self.hllx, = figDict['llaxis'].plot(xhistCenters, xhistValues * 0.25 * 
                (ylimits[1] - ylimits[0]) / float(max(xhistValues)) + ylimits[0], 'k-')
            self.hlly, = figDict['llaxis'].plot(yhistValues * 0.25 * (xlimits[1] - xlimits[0]) / 
                float(max(yhistValues)) + xlimits[0], yhistCenters, 'k-')
            
        if not choice == 'xy': # p / e histogram
            xdata = []
            ydata = []
            for series in plr:
                xdata.extend(series.get_xdata())
                ydata.extend(series.get_ydata())
            xhistValues, xhistCenters = emithist(xdata)
            yhistValues, yhistCenters = emithist(ydata)         
            xlimits = figDict['lraxis'].get_xlim()
            ylimits = figDict['lraxis'].get_ylim()         
            self.hlrx, = figDict['lraxis'].plot(xhistCenters, xhistValues * 0.25 * 
                (ylimits[1] - ylimits[0]) / float(max(xhistValues)) + ylimits[0], 'k-')
            self.hlry, = figDict['lraxis'].plot(yhistValues * 0.25 * (xlimits[1] - xlimits[0]) / 
                float(max(yhistValues)) + xlimits[0], yhistCenters, 'k-')    

    showhist(self,'both')

    # Click to autoscale X/Y or P/E plots
    def rescale_fig(event):
        if not event.inaxes == None:
            for hist in [self.hllx, self.hlly]:
                hist.remove()
            event.inaxes.relim()
            event.inaxes.autoscale()
            showhist(self,'xy')
            event.inaxes.figure.canvas.draw()
            event.inaxes.figure.canvas.flush_events()

    def rescale_pefig(event): # Separate function for phase energy plot        
            
        if event.inaxes == None: # If an axis was clicked, rescale it
            if not plotData['dsdata']:
                self.statusbar.showMessage('No beam data available, cannot rescale axes')
                return
            x, y = event.x, event.y
            transx, transy =  plt.gca().transAxes.inverted().transform([x, y])
            # add multi-charge state checking!
            if (transx > 0) and (transy < 0): # X axis clicked
                if lrtype[0] == 'deg':      # deg -> ns
                    for series in plr:
                        series.set_xdata(series.get_xdata() * 10**3 / 
                            (360. * float(plotData['freq'])))
                        figDict['lraxis'].set_xlabel('Time [ns]')
                        lrtype[0] = 'ns'
                else:                       # ns -> deg
                    for series in plr:
                        series.set_xdata(series.get_xdata() * 
                            360. * float(plotData['freq']) / 10**3)
                        figDict['lraxis'].set_xlabel('Phase [deg]')
                        lrtype[0] = 'deg'                    
                figDict['lraxis'].ticklabel_format(style='sci', axis = 'x', scilimits=(-4,4))
            elif (transx < 0) and (transy > 0):
                if lrtype[1] == 'rel':      # rel -> abs
                    for series in plr:
                        series.set_ydata(series.get_ydata() + float(plotData['energyrp']))
                    figDict['lraxis'].set_ylabel('Energy [MeV]')
                    lrtype[1] = 'abs'
                    figDict['lraxis'].ticklabel_format(style='sci', axis = 'y', 
                        scilimits=(0,0), useOffset = False)
                elif lrtype[1] == 'abs':    # abs -> %
                    for series in plr:
                        series.set_ydata(100. * 
                            (series.get_ydata()) / float(plotData['energyrp']) - 100.)
                    figDict['lraxis'].set_ylabel('dE / E [%]')
                    lrtype[1] = 'pct'
                    figDict['lraxis'].ticklabel_format(style='sci', axis = 'y', 
                        scilimits=(-3,3), useOffset = False)
                else:                       # % -> rel
                    for series in plr:
                        series.set_ydata((series.get_ydata() + 100) * 
                            (float(plotData['energyrp'])/100) - 
                            float(plotData['energyrp']))
                    figDict['lraxis'].set_ylabel('Rel. Energy [MeV]')
                    lrtype[1] = 'rel'
                        
        # Redraw plot, with histograms (Just rescales plot if plot was clicked)
        for hist in [self.hlrx, self.hlry]: # Clear the histograms
            hist.remove()
        figDict['lraxis'].relim()
        figDict['lraxis'].autoscale()
        showhist(self,'pe')
        figDict['lraxis'].figure.canvas.draw()
        figDict['lraxis'].figure.canvas.flush_events()
        
    for pos in poslist[0:3]:
        figDict[pos+'fig'].canvas.mpl_connect('button_press_event', rescale_fig)
    figDict['lrfig'].canvas.mpl_connect('button_press_event', rescale_pefig) 
    
    # Draw the figure
    self.show()

def makeEnvPlot(self, plotData):
    # Set up figure
    figDict = {}
    title = re.sub('\s\s+',' ',plotData['title'])
    title = re.sub('envelopes','Envelopes:',title)
    title = re.sub('envelope ','Envelope: ', title)
    self.titleLabel.setText(title)
    figDict["envpane"] = self.envPane
    figDict["envfig"] = Figure()
    figDict["envaxis"] = figDict["envfig"].add_subplot(111)
    figDict["envcanvas"] = FigureCanvas(figDict["envfig"])
    figDict["envpane"].addWidget(figDict["envcanvas"])
    figDict["envcanvas"].draw()

    if plotData['graphtype'] == 3: # X / Y Envelope
        figDict['envaxis'].plot(plotData['z'], plotData['x']/2.)
        figDict['envaxis'].plot(plotData['z'], plotData['y']/2.)
        figDict['envaxis'].set_ylabel('4 RMS Half Width [cm]')
        
    if plotData['graphtype'] == 4: # dW / W Envelope
        figDict['envaxis'].plot(plotData['z'], plotData['dw'] * 0.1)
        figDict['envaxis'].set_ylabel('dW/W 4 RMS Full Width [%]')

    if plotData['graphtype'] == 5: # dPhi Envelope
        figDict['envaxis'].plot(plotData['z'], plotData['dphi'] * 0.91)
        figDict['envaxis'].set_ylabel('Phase Full Width [deg]')

    # Common Appearance Items
    figDict['envaxis'].set_xlabel('Z position [m]')
    figDict['envaxis'].plot(plotData['z'], 
            np.zeros(len(plotData['z'])),'k--') # x = zero line
    
    # Autoscale and redraw
    figDict["envaxis"].relim()
    figDict["envaxis"].autoscale_view()
    figDict["envfig"].canvas.draw()
    figDict["envfig"].canvas.flush_events()   

    # Draw the figure
    self.show()

def readPlotData(plotfilename, startpos, dsfile):
    # Reads the plot from 'plotfilename' starting at starting position 'startpos'
    
    plotData = {}
    
    with open(plotfilename) as plotfile:
        plotfile.seek(startpos)
        
        # Get Graph Type
        plotData['graphtype'] = int(plotfile.readline()) 
        
        if plotData['graphtype'] in [1, 6]:
            mcs = False
            
            if plotData['graphtype'] == 6:
                mcs = True
                plotfile.readline()     # Discard unknown number
                plotData['chgvals'] = plotfile.readline().split()
                plotData['chgvals'] = [int(float(i)) for i in plotData['chgvals']]
                plotData['nstates'] = len(plotData['chgvals'])
                
            # Get Graph Title    
            plotData['title'] = plotfile.readline().strip()
            
            # Get x x' graph Limits
            limits = plotfile.readline().split()
            plotData['xlim'] = (float(limits[0]), float(limits[1]))
            plotData['xplim'] = (float(limits[2]), float(limits[3]))
            
            # Read in x x' oval
            plotData['xxpoval'] = np.zeros((201,2))
            plotData['isoval'] = False
            for i in range(201):
                plotData['xxpoval'][i] = plotfile.readline().split() 
            if (not plotData['xxpoval'][0,0] == plotData['xxpoval'][1,0]) and (
                    not plotData['xxpoval'][1,0] == plotData['xxpoval'][1,1]):
                plotData['isoval'] = True
                plotData['xxpoval'] = np.array(plotData['xxpoval'])
                plotData['xxpoval'] = plotData['xxpoval'].T
            
            # Read in actual x x' data
            plotData['npart'] = int(plotfile.readline().strip())
            if mcs:             # Initialize all multi charge state arrays
                plotData['xchg'] = np.zeros(plotData['npart']) 
                plotData['ychg'] = np.zeros(plotData['npart'])
                plotData['pechg'] = np.zeros(plotData['npart'])
            plotData['x'] = np.zeros(plotData['npart'])
            plotData['xp'] = np.zeros(plotData['npart'])
            for i in range(plotData['npart']):
                linein = plotfile.readline().split()
                plotData['x'][i] = float(linein[0])
                plotData['xp'][i] = float(linein[1])
                if mcs:
                    plotData['xchg'][i] = np.round(float(linein[2])).astype(np.int)
                    
            # Get y y' graph Limits
            limits = plotfile.readline().split()
            plotData['ylim'] = (float(limits[0]), float(limits[1]))
            plotData['yplim'] = (float(limits[2]), float(limits[3]))
            
            # Read in y y' oval
            plotData['yypoval'] = np.zeros((201,2))
            for i in range(201):
                plotData['yypoval'][i] = plotfile.readline().split()
            if plotData['isoval']:
                plotData['yypoval'] = np.array(plotData['yypoval'])
                plotData['yypoval'] = plotData['yypoval'].T    
            
            # Read in actual y y' data
            plotData['npart'] = int(plotfile.readline().strip())
            plotData['y'] = np.zeros(plotData['npart'])
            plotData['yp'] = np.zeros(plotData['npart'])
            for i in range(plotData['npart']):
                linein = plotfile.readline().split()
                plotData['y'][i] = float(linein[0])
                plotData['yp'][i] = float(linein[1])
                if mcs:
                    plotData['ychg'] = np.round(float(linein[2])).astype(np.int)
        
            # Discard redundant information
            plotfile.readline()
            
            # Read z z' graph limits
            limits = plotfile.readline().split()
            plotData['plim'] = (float(limits[0]), float(limits[1]))
            plotData['elim'] = (float(limits[2]), float(limits[3]))
            
            # Read in z z' oval
            plotData['peoval'] = np.zeros((201,2))
            for i in range(201):
                plotData['peoval'][i] = plotfile.readline().split()
            if plotData['isoval']:
                plotData['peoval'] = np.array(plotData['peoval'])
                plotData['peoval'] = plotData['peoval'].T  
            
            # Read in z z' data
            plotData['npart'] = int(plotfile.readline().strip())
            plotData['deg'] = np.zeros(plotData['npart'])
            plotData['relenergy'] = np.zeros(plotData['npart'])
            for i in range(plotData['npart']):
                linein = plotfile.readline().split()
                plotData['deg'][i] = float(linein[0])
                plotData['relenergy'][i] = float(linein[1])
                if mcs:
                    plotData['pechg'] = np.round(float(linein[2])).astype(np.int)
            # To Do - find some way of getting the frequency in here
        
        elif plotData['graphtype'] == 3:        # X/Y Envelope Plot
            # Get Graph Title    
            plotData['title'] = plotfile.readline().strip()
            
            # Read z x graph limits
            limits = plotfile.readline().split()
            plotData['zlim'] = (float(limits[0]), float(limits[1]))
            plotData['xlim'] = (float(limits[2]), float(limits[3]))

            # Get z, x, y data
            plotData['npoints'] = int(plotfile.readline().strip())
            plotData['z'] = np.zeros(plotData['npoints'])
            plotData['x'] = np.zeros(plotData['npoints'])
            for i in range(plotData['npoints']):
                linein = plotfile.readline().split()
                plotData['z'][i] = float(linein[0])
                plotData['x'][i] = float(linein[1])

            plotData['npoints'] = int(plotfile.readline().strip())
            plotData['y'] = np.zeros(plotData['npoints'])
            for i in range(plotData['npoints']):
                linein = plotfile.readline().split()
                plotData['y'][i] = float(linein[1])            
        
        elif plotData['graphtype'] == 4:            # dW/W Envelope Plot
            # Get Graph Title    
            plotData['title'] = plotfile.readline().strip()
            
            # Read z x graph limits
            limits = plotfile.readline().split()
            plotData['zlim'] = (float(limits[0]), float(limits[1]))
            plotData['dwlim'] = (float(limits[2]), float(limits[3]))

            # Get z, x, y data
            plotData['npoints'] = int(plotfile.readline().strip())
            plotData['z'] = np.zeros(plotData['npoints'])
            plotData['dw'] = np.zeros(plotData['npoints'])
            for i in range(plotData['npoints']):
                linein = plotfile.readline().split()
                plotData['z'][i] = float(linein[0])
                plotData['dw'][i] = float(linein[1])

        elif plotData['graphtype'] == 5:            # dPhi Envelope Plot
            # Get Graph Title    
            plotData['title'] = plotfile.readline().strip()
            
            # Read z x graph limits
            limits = plotfile.readline().split()
            plotData['zlim'] = (float(limits[0]), float(limits[1]))
            plotData['dphilim'] = (float(limits[2]), float(limits[3]))

            # Get z, x, y data
            plotData['npoints'] = int(plotfile.readline().strip())
            plotData['z'] = np.zeros(plotData['npoints'])
            plotData['dphi'] = np.zeros(plotData['npoints'])
            for i in range(plotData['npoints']):
                linein = plotfile.readline().split()
                plotData['z'][i] = float(linein[0])
                plotData['dphi'][i] = float(linein[1])

        else: 
            print "Unknown graph type: %g" % plotdata['graphtype']
            quit()
        
        # Get beam data from 'dynac.short'
        plotData['dsdata'] = False
        if os.path.isfile(dsfile):
            with open(dsfile) as ds:
                linein = ds.readline()
                while linein:
                    if plotData['title'] in linein: 
                        plotData['dsdata'] = True
                        linein = ds.readline()
                        linein = ds.readline().split() 
                        plotData.update({'betarp':linein[0],
                            'energyrp':linein[1],'tofrp':linein[2],
                            'energycog':linein[3],'tofcog':linein[4],
                            'eoffsetcog':linein[5], 'toffsetcog':linein[6]})
                        linein = ds.readline().split() 
                        plotData.update({'xcog':linein[0],'xpcog':linein[1],
                            'ycog':linein[2],'ypcog':linein[3]})
                        linein = ds.readline().split()
                        plotData.update({'alphax':linein[0],'betax':linein[1],
                            'alphay':linein[2],'betay':linein[3],
                            'alphaznk':linein[4],'betaznk':linein[5]})
                        linein = ds.readline().split()
                        plotData.update({'alphazdk':linein[0],
                            'betazdk':linein[1],'emitzdk':linein[2],
                            'freq':linein[4]})
                        linein = ds.readline().split()
                        plotData.update({'phiwidth':linein[0],
                            'ewidth':linein[1], 'rphie':linein[2], 
                            'emitznk':linein[3], 'nparticles':linein[5]})
                        linein = ds.readline().split()
                        plotData.update({'xwidth':linein[0], 
                            'xpwidth':linein[1], 'rxxp':linein[2], 
                            'emitxnorm':linein[3], 'emitxnon':linein[6]})
                        linein = ds.readline().split()
                        plotData.update({'ywidth':linein[0], 
                            'ypwidth':linein[1], 'ryyp':linein[2], 
                            'emitynorm':linein[3], 'emitynon':linein[6]})                        
                                
                        linein = False # Ends loop
                    else:
                        linein = ds.readline()
        
    return plotData

def plotGraph(plotData):
    if plotData['graphtype'] in [1, 6]:
        window = EmitPlot(plotData)
        return window
    elif plotData['graphtype'] in [3, 4, 5]: # test values 1092877, 1094188, 1094945
        window = EnvPlot(plotData)
        return window
    else:
        print 'Unknown Plot Type: %g' % plotData['graphtpe']
        quit()   
      
if __name__ == '__main__':
    # Code that executes if this script is called directly
    plotfilename = 'emit.plot' 
    startpos = 0                    # Default to start of file
    dsfile = 'dynac.short'          # Default dynac.short file
    
    # Process command line options
    options, remainder = getopt.getopt(sys.argv[1:], 's:f:d:')
    for opt, arg in options:
        if opt in '-s':             # Starting position in the file in bytes
            startpos = int(arg)     # 195126 for test value
        if opt in '-f':             # Input file name
            plotfilename = arg
        if opt in '-d':            # Alternate for dynac.short
            dsfile = arg
    
    plotData=readPlotData(plotfilename, startpos, dsfile)   
    app = QtGui.QApplication(sys.argv)
    window = plotGraph(plotData)
    sys.exit(app.exec_())
