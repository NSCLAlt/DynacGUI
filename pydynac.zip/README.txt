Python scripts for working with Dynac files


"""
dynaczplot.py

Scans "dynac.print" file and produces longitudinal plots.

Usage dynaczplot.py [-f filename default='dynac.print'] 
                    [-s dynac.short filename default='dynac.short']

If dynac.short is present, will scan it for the locations of emittance plots

Requires: dynaczplot.ui
"""


"""
emitplot.py

Plots data from a Dynac generated emit.plot file.  

Usage:
python emitplot.py [-f filename] [-s starting position]

filename: File to scan for plot data.  Default: "emit.plot"
starting postion: Position within the file, in bytes,
                        of the data to plot.  Default: 0

Requires: emitplot.ui
"""

"""
gendeck.py

Reproduces functionality (mostly) of gendeck.m from DynacGUI, the Matlab front
end for Dynac.  When called as a standalone script, builds the .in file with
the same name as the tune settings file.

Usage:

gendeck.py [-d Device File Name] [-l Layout File Name] [-t Settings File Name]
    [-p Particle Distribution File (optional)]


"""

"""
plotpick.py

Scans a Dynac generated *.plot output file and presents a list of the contained
plots.  Allows the user to select a plot and display it using emitplot.py. User
can also select a different filename than the default "emit.plot".

Requires: plotpick.ui, emitplot.py, emitplot.ui
"""