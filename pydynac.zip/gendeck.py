# -*- coding: utf-8 -*-
"""
gendeck.py

Reproduces functionality (mostly) of gendeck.m from DynacGUI, the Matlab front
end for Dynac.  When called as a standalone script, builds the .in file with
the same name as the tune settings file.

Usage:

gendeck.py [-d Device File Name] [-l Layout File Name] [-t Settings File Name]
    [-p Particle Distribution File]

Eventually could be modified to act as a module for a full port of DynacGUI.
Don't hold your breath.
"""
from collections import defaultdict
import re
import os
import getopt
import sys

def nodevice(device, type, idx):
    throwerror("%s device type %s not found in %s" % 
        (device, type, devicefilename) , 0, idx) 
    
def throwerror(text, flag, idx = -1):
    # For a given error, write the message to the outputfile and stdout
    outputfile.writelines(";Error: %s\n" % text)
    if idx == -1:
        print ("Error: " + text)
    else:
        print ("Error in layout file, line %s: " % str(idx) + text)
    if flag == 1: # if the flag is 1, quit deck generation
        quit()


# Default Input parameters 
devicefilename="ReA3Devices.txt"
layoutfilename="ReA3Layout.txt"
tunefilename="ReA3_40Ar13_L016_JANUS_020816Alt.txt"
outputfilename = tunefilename.replace(".txt",".in")
inputdistfile = ""

# Process command line options
options, remainder = getopt.getopt(sys.argv[1:], 'd:l:t:')
for opt, arg in options:
    if opt in '-d':
        devicefilename = arg
    elif opt in '-l':
        layoutfilename = arg
    elif opt in '-t':
        tunefilename = arg
    elif opt in '-p':
        inputdistfile = arg
        
RFQreject=0.5 #Fractional deviation from average energy to be rejected after RFQ. Note
              #that this is from the average INCLUDING the unaccelerated
              #beam. (Fixed to relative to RP for Dynac v. 15 and up)
esectors=10     # Number of sectors for electrostatic bending elements
bsectors=10     # Number of sectors for magnetic bending elements
csectors=8      # Number of integration steps in cavities
longdist = 0    # Set manually for now, worry about later
nstates = 1     # Default value

dynac_version = 15

#Dynac version specific checks

if dynac_version <= 12: #Set E deflector type based on version
    edflectype=3
else:
    edflectype=4;

if dynac_version <= 14: #For versions without RP referencing, use cog in all cases
    reject[5] = reject[6] % 10

#Default REJECT values
#Energy[Flag] Phase[deg] X[cm] Y[cm] R[cm] Flag - All are 1/2 widths
#Flag=1, Energy is absolute value in MeV from cog.
#Flag=0, Energy is fractional deviation from cog.
#Flag=11, Energy is absolute deviation from RP.
#Flag=10, Energy is fractional deviation from RP.
reject=[1000, 4000, 100, 100, 400, 11]


# Read Tune Settings, initialize running parameters
with open(tunefilename) as tunefile:
    settings = dict(line.strip().split(None, 1) for line in tunefile)
runfreq = float(settings['RF'])
freqlist = []
cavfield = ''

# Initialize unit dictionary 
unit_dict={}
unit_dict = unit_dict.fromkeys(settings,"")  
unit_dict['A'] = "[AMU]"
unit_dict['Q'] = "[Q]"
unit_dict['RF'] = "[Hz]"
unit_dict['Betax'] = "[mm/mrad]"
unit_dict['Epsx'] = "[mm.mrad]"
unit_dict['Betay'] = "[mm/mrad]"
unit_dict['Epsy'] = "[mm.mrad]"
unit_dict['Deltae'] = "[MV]"
unit_dict['Energy'] = "[MV]"

# Read in Device Information from device file
device_dict = {}
device_dict = defaultdict(list)

with open(devicefilename) as devicefile:
    for line in iter(devicefile):
        line = line.strip('\n')
        a, c, b = line.partition('\t')
        device_dict[a] = b.split('\t')

#Open Output File For Writing    
outputfile = open(outputfilename,'w')

# Check for ZLaw parameter, set to 5 if not present.
if not "ZLaw" in settings: #If no ZLaw specified, default to 5
    settings['ZLaw'] = "5"
    unit_dict['ZLaw'] = ""
elif int(settings['ZLaw']) <= 4 and not ("Alphaz" in settings and
    "Betaz" in settings and "Epsz" in settings): 
    # If <4 is selected, check for needed values
    throwerror("ZLaw 4 selected without enough Z parameters defined.", 1)
elif settings['ZLaw'] == "5" and not "Deltae" in settings:
    throwerror("ZLaw 5 selected without energy spread.", 1)

# Write header information
if longdist == 2:               # Reserved for post RFQ beamline with split
    outputfile.writelines("RFQ period splitting not yet supported\n")
    outputfile.close()
    quit()
    
elif inputdistfile != "":       # If a particle distribution file is used
    outputfile.writelines(';' + outputfilename + '\n')  # File Name
    outputfile.writelines('RDBEAM\n')                   # Read Beam Command
    outputfile.writelines('%s\n' % inputdistfile)       # Distribution File
    outputfile.writelines('2\n')                        # Include charge states
    outputfile.writelines('%g 0\n' % (float(settings['RF']) * 10**(-6))) # MHz, Phi
    outputfile.writelines('931.494 %s\n' % settings['A'])   # AMU, A
    outputfile.writelines('%s %s\n' % (settings['Energy'], settings['Q']))
    
else:                           # Standard branch with CS parameters
    outputfile.writelines(";" + outputfilename +"\n")   #File Name
    outputfile.writelines("GEBEAM\n")                   
    outputfile.writelines("%s 1\n" % settings['ZLaw'])  #Zlaw
    outputfile.writelines("%s\n" % settings['RF'])      #RF Frequency
    outputfile.writelines("%s\n" % settings['Npart'])   #Number of Particles
    outputfile.writelines("0 0 0 0 0\n")                #Starting Offset
    
    #Transverse Parameters
    outputfile.writelines("%s %s %s\n" % 
        (settings['Alphax'], settings['Betax'], settings['Epsx']))
    outputfile.writelines("%s %s %s\n" % 
        (settings['Alphay'], settings['Betay'], settings['Epsy']))
    #Energy Parameters
    if settings['ZLaw'] == "5":
        outputfile.writelines("%s 0 0\n" % settings['Deltae'])
    else:
        outputfile.writelines("%s %s %s\n" % 
            (settings['Alphaz'], settings['Betaz'], settings['Epsz']))
        unit_dict['Betaz'] = '[deg/keV]'
        unit_dict['Epsz'] = '[deg.keV]'
    
    #Beam particles
    outputfile.writelines("INPUT\n")
    outputfile.writelines("931.49432 %s %s\n" % (settings['A'], settings['Q']))
    outputfile.writelines("%s 0\n" % settings['Energy'])

    # Add Multi Charge State stuff here
    if 'Nstates' in settings:
        nstates = int(settings['Nstates'])
        if nstates == 0:            # Can be updated later
            throwerror(
                'Reading charge states from input file not supported', 0)
        elif nstates == 1:          # Do nothing - this branch is pointless
            pass
        else:                       # Main muli-charge branch
            if nstates > 20:        # Check for too many charge states
                throwerror('No more than 20 charge states allowed', 1)
            outputfile.writelines('ETAC\n')
            outputfile.writelines('%g\n' % nstates)
            for k in range(1,nstates+1):
                try:
                    outputfile.writelines('%s %s %s\n' % (
                        settings['cs' + str(k)],
                        settings['cspcent' + str(k)],
                        settings['cseoff' + str(k)]))
                    unit_dict['cs' + str(k)] = '[Q]'
                    unit_dict['cspcent' + str(k)] = '[%]'
                    unit_dict['cseoff' + str(k)] = '[MeV]'
                except KeyError:
                    thorwerror('Missing charge state data', 1)
            
            # Adujst deflector sectors if needed
            esectors = max(esectors, 2)
            bsectors = max(bsectors, 2)
                    
nplots = 1 # Number of plots

with open(layoutfilename) as layoutfile:

    #for line in iter(layoutfile): 	# Scan each line in layout file
    for idx,line in enumerate(layoutfile):

        if re.match('^;',line):		# Skip Comments
            outputfile.writelines(line)
            continue
        card, _ , allcardvals = line.partition('\t') # Process line
        card = card.strip()
        cardvals = allcardvals.split('\t')
        for i, value in enumerate(cardvals): 
            cardvals[i] = cardvals[i].strip()
			
        if card == "ACCEPT":		# Acceptance plot
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            xlim = device_dict[id][1]
            xplim = device_dict[id][2]
            zlim = device_dict[id][3]
            zplim = device_dict[id][4]
            outputfile.writelines("ACCPT\n")
            outputfile.writelines("%s\n",cardvals[1])
            outputfile.writelines("1 %s\n",device_dict[id][0])
            outputfile.writelines("%s %s %s %s %s %s %s %s" %
                (xlim, xplim, xlim, xplim, xlim, xlim, zlim, zplim))
            outputfile.writelines("%s\n",cardvals[2])
            outputfile.writelines("1 %s\n",device_dict[id][0])
            outputfile.writelines("%s %s %s %s %s %s %s %s" %
                (xlim, xplim, xlim, xplim, xlim, xlim, zlim, zplim))
            freqlist.append(runfreq)
            freqlist.append(runfreq)
            nplots += 2
			
        elif card == "BMAGNET":		# Magnetic Dipole
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if len(cardvals) >= 3 and cardvals[2] in device_dict :
                bfield = cardvals[2]
                unit_dict[cardvals[2]] = ['kG']
            else:
                bfield = '0'
            outputfile.writelines("BMAGNET\n")
            outputfile.writelines("%s\n" % bsectors)
            outputfile.writelines("%s %s %s %s %s\n" % 
                (device_dict[id][0], device_dict[id][1], bfield, '0', '0'))
            outputfile.writelines("%s %s %s %s %s\n" %
                (device_dict[id][2], device_dict[id][3],'0.45','2.8',
                 device_dict[id][4]))
            outputfile.writelines("%s %s %s %s %s\n" % 
                 (device_dict[id][5], device_dict[id][6], '0.45','2.8',
                  device_dict[id][7]))
				  
        elif card == "BUNCHER":		# Sinusoidal Buncher
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[2] in settings:
                throwerror("No tune setting for %s" % cardvals[2],0,idx)
                continue
            if not cardvals[3] in settings:
                throwerror("No tune setting for %s" % cardvals[3],0,idx)
                continue
            outputfile.writelines("BUNCHER\n")
            outputfile.writelines("%s %s %s %s\n" % (settings[cardvals[2]],
                     settings[cardvals[3]], cardvals[1],device_dict[id][0]))
            unit_dict[cardvals[2]]="[MV]"
            unit_dict[cardvals[3]]="[deg]"
			
        elif card == "CAVNUM":		# Accelerating Cavity
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if cavfield != device_dict[id][0]: #If this is a new cavity type
                cavfield = device_dict[id][0]
                #Later - throw error if field missing
                outputfile.writelines("FIELD\n") #Write a FIELD card
                #Later - adjust for scratch directory        
#                %If we're writing to the scratch directory, adjust.
#                if isfield(settings,'longdist') && settings.longdist>=1
#                    fprintf(outfile,'%s\r\n',['..' filesep cavfield]);
#                else
                outputfile.writelines("%s\n" % os.path.relpath(cavfield))
                outputfile.writelines("1\n")
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[2], 0, idx)
                continue
            if not cardvals[2] in settings:
                throwerror("No tune setting for: %s" % cardvals[3], 0, idx)
                continue
            outputfile.writelines("CAVNUM\n")
            outputfile.writelines("1\n")
            outputfile.writelines("0 %s %f %s 1\n" % (
                settings[cardvals[2]], float(settings[cardvals[1]]) -100,
                csectors))
            unit_dict[cardvals[1]] = "[%]"
            unit_dict[cardvals[2]] = "[deg]"             
			
        elif card == "DRIFT":		# Drift 
            outputfile.writelines("DRIFT\n")
            outputfile.writelines("%s\n" % cardvals[0])
			
        elif card == "EDFLEC":		# Electrostatic bender
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            outputfile.writelines("EDFLEC\n")
            outputfile.writelines("%s\n" % esectors)
            if edflectype == 3: #Older input file with only 3 paramters
                outputfile.writelines("%s %s %s\n" % (device_dict[id][0],
                              device_dict[id][1], device_dict[id][2]))
            else:
                if len(cardvals) == 2:
                    efield = "-1";
                elif cardvals[1] in settings:
                    efield = settings[cardvals[1]]
                    unit_dict[cardvals[1]] = "[kV/cm]"
                else:
                    efield = "-1"
                    unit_dict[cardvals[1]] = "[kV/cm]"
            outputfile.writelines("%s %s %s %s\n" % (device_dict[id][0],
                     device_dict[id][1], device_dict[id][2], efield)) 
					 
        elif card == "EMIT":		# Output beam data to dynac.short
            outputfile.writelines("EMIT\n")
			
        elif card == "EMITL":		# Output beam data with label 
            outputfile.writelines("EMITL\n")
            outputfile.writelines("%s\n" % cardvals[0])
			
        elif card == "EMITGR":		# Output emittance graph data to emit.plot
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            xlim = device_dict[id][1]
            xplim = device_dict[id][2]
            zlim = device_dict[id][3]
            zplim = device_dict[id][4]
            outputfile.writelines("EMITGR\n")
            outputfile.writelines("%s\n" % cardvals[1])
            outputfile.writelines("%s %s %s %s %s %s %s %s\n" % 
                (xlim, xplim, xlim, xplim, xlim, xlim, zlim,zplim))
            freqlist.append(runfreq)
            nplots += 1
            outputfile.writelines("EMITL\n")
            outputfile.writelines("%s\n" % cardvals[1])
			
        elif card == "ENVEL":		# Output envelope plot data to emit.plot
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            outputfile.writelines("ENVEL\n")
            outputfile.writelines("%s\n" % cardvals[1])
            outputfile.writelines("%s\n" % device_dict[id][0])
            outputfile.writelines("%s %s\n" % (device_dict[id][1],
                                               device_dict[id][2]))
            outputfile.writelines("0 0 0 0\n")
            freqlist.append(runfreq)
            nplots += 1
			
        elif card == "FDRIFT":		# Subdivided drift
            outputfile.writelines("FDRIFT\n")
            outputfile.writelines("%s %s 1\n" % (cardvals[0], cardvals[1]))
			
        elif card == "FIRORD": 		# Set calculation order to first order
            outputfile.writelines("FIRORD\n") 
			
        elif card == "FSOLE":		# Solenoid from external field file
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            solfile = device_dict[id][0]
            #Later: Throw warning if file missing
            nparts = device_dict[id][1]
            outputfile.writelines("FSOLE\n")
            outputfile.writelines("%s\n" % os.path.relpath(solfile))
            outputfile.writelines("%s %s\n" % (settings[cardvals[1]], nparts))
            unit_dict[cardvals[1]] = "[kG]"
			
        elif card == "MMODE":		# Cavity error mode
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            outputfile.writelines("MMODE\n")
            outputfile.writelines("%s %s %s\n" % (device_dict[id][0],
                              device_dict[id][1], device_dict[id][2]))
							  
        elif card == "NEWF":		# Set new frequency in Hz
            outputfile.writelines("NEWF\n")
            outputfile.writelines("%s\n" % cardvals[0])
            runfreq = float(cardvals[0])
			
        elif card == "NREF":		# Set new reference particles
            outputfile.writelines("NREF\n")
            outputfile.writelines("%s %s %s %s\n" % (cardvals[0], 
                         cardvals[1], cardvals[2], cardvals[3]))
						 
        elif card == "QUADRUPO":	# Magnetic quadrupole
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            outputfile.writelines("QUADRUPO\n")
            outputfile.writelines("%s %s %s\n" % (device_dict[id][0],
                          settings[cardvals[1]], device_dict[id][1]))
            unit_dict[cardvals[1]] = "[kG]"   
			
        elif card == "QUADSXT":		# Combined quadrupole / sextupole
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            if not cardvals[2] in settings:
                throwerror("No tune setting for: %s" % cardvals[2], 0, idx)
                continue
            outputfile.writelines("QUADSXT\n")
            outputfile.writelines("1 %s 1 %s %s %s\n" % 
                (settings[cardvals[1]], settings[cardvals[2]], 
                   device_dict[id][0], device_dict[id][1]))
            unit_dict[cardvals[1]] = "[kG]"
            unit_dict[cardvals[2]] = "[kG]"
			
        elif card == "QUAELEC":		# Electrostatic Quadrupole
            id = cardvals[0]
            #check to see if this quad type is in the device list
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            #check to see if this particular quad is in the settings list
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            outputfile.writelines("QUAELEC\n")
            outputfile.writelines('%s %s %s\n' % (device_dict[id][0],
                            settings[cardvals[1]], device_dict[id][1]))
            unit_dict[cardvals[1]]="[kV]"            
			
        elif card == "REJECT":		# Change rejection window
			id = cardvals[0]
			if not id in device_dict:
				nodevice(card, id, idx)
				continue
			for i in range(1,6):
				reject[i - 1] = float(device_dict[id][i-1])
			if reject[0] < 0:
				reject[5] = 0
				reject[0] = abs(reject[0])
			else:
				reject[5] = 1
			if dynac_version >= 15:
				reject[5] = reject[5] + 10
			outputfile.writelines("REJECT\n")
			outputfile.writelines("%g %g %g %g %g %g\n" % (reject[5], reject[0],
					reject[1], reject[2], reject[3], reject[4]))
					
        elif card == "REFCOG":		# Change R.P / C.O.G. coupling 
            outputfile.writelines("REFCOG\n")
            outputfile.writelines("%s\n" % cardvals[0])
			
        elif card == "RFKICK":		# RF Kicker
            id = cardvals[0]
            if not id in device_dict:
		        nodevice(card, id, idx)
            continue
            steertype = device_dict[id][0]
            if not cardvals[2] in settings:
                throwerror("No tune setting for: %s" % cardvals[2], 0, idx)
                continue
            if not cardvals[3] in settings:
                throwerror("No tune setting for: %s" % cardvals[3], 0, idx)
                continue
            len = float(device_dict[id][1])
            gap = float(device_dict[id][2])
            voltage = settings[cardvals[2]]
            phase = settings[cardvals[3]]
            field = voltage * len /gap
            outputfile.writelines("%g %g %s %s\n" % 
                (field, phase, cardvals[1], steertype))
            unit_dict[cardvals[2]] = "[KV]"
            unit_dict[cardvals[3]] = "[deg]"
            
        elif card == "RFQPTQ":      # RFQ
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                
            # This branch terminates the deck generation just before the 
            # start of the RFQ if "longdist" is equal to 1.
            if longdist == 1:
                distfile = outputfilename.replace('.in','.dst')
                distfile = distfile.replace('dynacscratch.','')
                outputfile.writelines("WRBEAM\n")
                outputfile.writelines('%s\n' % distfile)
                outputfile.writelines('1 2\n')
                outputfile.writelines('STOP\n')
                # ADD CODE TO RETURN RFQ PARAMETERS
                outputfile.close()
                quit()
                
            # Run this branch otherwise    
            outputfile.writelines('REFCOG\n')
            outputfile.writelines('1\n')
                        
            # Calculate the difference between the reference particle energy and
            # the design energy of the RFQ.  Set new reference particle value.
            # NOTE: Assumes reference particle is still at its initial energy. 
            # The only way to fix this would be to always break in the middle of 
            # a deck with an RFQ.
            rfqenergy = float(device_dict[id][2]) # RFQ design input energy
            param2 = (float(settings['A']) * rfqenergy) - float(settings['Energy']) 
            outputfile.writelines('NREF\n')
            outputfile.writelines('0 %g 0 1\n' % param2)
            
            # Values for RFQ Card itself
            rfqfilename = device_dict[id][0]
            if os.path.sep != '/':
                rfqfilename = rfqfilename.replace("\\", "/")
            else:
                rfqfilename = rfqfilename.replace("/", "\\")
            # Add some error checking to see if the file exists
            rfqdegrees = settings[cardvals[2]]
            rfqphaseoffset = 100. * float(rfqdegrees) / 360. # Convert to percent            
            outputfile.writelines('RFQPTQ\n')
            outputfile.writelines('%s\n' % rfqfilename)
            outputfile.writelines('%s\n' % device_dict[id][1])
            outputfile.writelines('%g %g %g 180\n' % (
                float(settings[cardvals[1]]) - 100, 
                float(settings[cardvals[1]]) - 100, 
                rfqphaseoffset))
                
            # Post RFQ Rejection
            if dynac_version >= 15:
                rflag = 10
            else:
                rflag = 0
            outputfile.writelines('REJECT\n')
            outputfile.writelines('%g %g %g %g %g %g\n' % (rflag, RFQreject,
                reject[1], reject[2], reject[3], reject[4]))
            outputfile.writelines('DRIFT\n')
            outputfile.writelines('0.00001\n')
            outputfile.writelines('REJECT\n')
            outputfile.writelines('%g %g %g %g %g %g\n' % (reject[5],             
                reject[0], reject[1], reject[2], reject[3], reject[4]))
            outputfile.writelines('REFCOG\n')
            outputfile.writelines('0\n')
            unit_dict[card[1]] = '[%]'
            unit_dict[card[2]] = '[deg]'
            
        elif card == "SCDYNAC":     #Space Charge
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                
            sctype = device_dict[id][0] # Space Charge Model
            
            # Error checking
            if not cardvals[0] in settings:
                throwerror("No tune setting for: %s" % cardvals[0], 0, idx)
                continue
            if not (nstates == 1) and (sctype == '3'):
                throwerror("Space charge modes other than SCHEFF not " +
                    "supported for multi-charge state beams.", 0, idx)
                continue
            
            # Write output card
            outputfile.writelines('SCDYNAC\n')
            outputfile.writelines('%s\n' % sctype)
            outputfile.writelines('%g %s\n' % (settings[cardvals[1]],
                device_dict[id][1]))
            # Switch on space charge model - consult documentation
            if sctype == '1':           # HERSC model, default
                outputfile.writelines('%s\n' % device_dict[id][2])
            elif sctype == '-1':     # HERSC model, specified
                outputfile.writelines('%s %s %s\n' % (device_dict[id][2],
                    device_dict[id][3], device_dict[id][4]))
                outputfile.writelines('%s %s %s\n' % (device_dict[id][5],
                    device_dict[id][6], device_dict[id][7]))
                outputfile.writelines('%s\n' % (device_dict[id][8]))
            elif sctype == '2':      # Modified Hermite
                outputfile.writelines('0\n')
            elif sctype == '3':
                schefftype = device_dict[id][2]
                outputfile.writelines('%s\n' % schefftype)
                if schefftype == '1':
                    outputfile.writelines('%s %s %s %s %s %s %s\n' %
                        (device_dict[id][3], device_dict[id][4],
                            device_dict[id][5], device_dict[id][6], 
                            device_dict[id][7], device_dict[id][8],
                            device_dict[id][9]))
            else:
                throwerror("Unknown space charge model" % cardvals[1], 1, idx)
            
            # Make sure B sectors is even
            if (bsectors % 2) != 0:
                bsectors += 1
                
        elif card == "SCDYNEL":        # Turn on space charge in mag dipoles
            outputfile.writelines('SCDYNEL\n')
            outputfile.writelines('%s\n' % cardvals[0])
            
        elif card == "SCPOS":          # Space charge position in cavities
            outputfile.writelines('SCPOS\n')
            outputfile.writelines('%s\n' % cardvals[0])
            
        elif card == "SECORD":          # Turn on second order computation
            outputfile.writelines('SECORD\n')

        elif card == "SEXTUPO":         # Magnetic sextupole
            # Note - functions as drift if SECORD is not on
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            outputfile.writelines("SEXTUPO\n")
            outputfile.writelines("1 %g %s %s\n" % (settings[cardvals[1]],
                device_dict[id][0], device_dict[id][1]))
            unit_dict[cardvals[1]] = "[kG]"
            
        elif card == "SLIT":             # Horizontal or vertical slit
            # Error checking
            for i in range(2):
                if not cardvals[i] in settings:
                    throwerror('Missing tune setting for %s' % cardvals[i], 
                        0, idx)
                    continue
            outputfile.writelines('REJECT\n')
            # Factor of 2 in the following is because Dynac uses half widths
            outputfile.writelines('%g %g %g %g %g %g\n' % (
                reject[5], reject[0], reject[1], 
                float(settings[cardvals[0]])/2.,
                float(settings[cardvals[1]])/2., reject[4]))
            outputfile.writelines('DRIFT\n')
            outputfile.writelines('0.00001\n')
            outputfile.writelines('REJECT\n')
            outputfile.writelines('%g %g %g %g %g %g\n' % (
                reject[5], reject[0], reject[1], 
                reject[2], reject[3], reject[4]))
            unit_dict[cardvals[0]] = "[cm]"
            unit_dict[cardvals[1]] = "[cm]"
            
        elif card == "SOLENO":           # Solenoid
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            outputfile.writelines('SOLENO\n')
            outputfile.writelines('1 %s %s\n' % (device_dict[id][0],
                settings[cardvals[1]]))
            unit_dict[cardvals[1]] = "[kG]"
            
        elif card == "SOQUAD":           # Combined magnetic quad / solenoid
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            for i in range(1,3):
                if not cardvals[i] in settings:
                    throwerror("No tune setting for: %s" % cardvals[i], 0, idx)
                    continue
            outputfile.writelines('SOQUAD\n')
            outputfile.writelines('1 %g 1 %g %s %s\n' % (
                settings[cardvals[1]], settings[cardvals[2]],
                device_dict[id][0], device_dict[id][1]))
            unit_dict[cardvals[1]] = '[kG]'
            unit_dict[cardvals[2]] = '[kG]'
            
        elif card == "STEER":            # Steering Dipole
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            if not cardvals[1] in settings:
                throwerror("No tune setting for: %s" % cardvals[1], 0, idx)
                continue
            steertype = device_dict[id][0]
            if (steertype == '2') or (steertype == '3'):
                slength = float(device_dict[id][1])
                gap = float(device_dict[id][2])
                voltage = float(settings[cardvals[1]])
                field = voltage * slength / gap
                unit_dict[cardvals[1]] = '[kV]'
            else:
                field = settings[cardvals[1]]
                unit_dict[cardvals[1]] = '[kG]'
            outputfile.writelines('STEER\n')                
            outputfile.writelines('%g %s\n' % (field, steertype))
            
        elif card == "STOP":            # Break layout here
            break            
        
        elif card == "WRBEAM":          # Write particle distribution file
            outputfile.writelines('WRBEAM\n')
            outputfile.writelines('%s\n' % cardvals[0])
            if dynac_version <= 14:
                outputfile.writelines('1 2\n')
            else:
                outputfile.writelines('1 102\n')
                
        elif card == "ZONES":           # Begin tracking RMS zones
            id = cardvals[0]
            if not id in device_dict:
                nodevice(card, id, idx)
                continue
            nzones = len(device_dict[id])    
            ztype = device_dict[id][0]
            outputfile.writelines('ZONES\n')
            if ztype == '-1':           # Zone tracking is to be disabled
                outputfile.writelines('1 0\n')
                outputfile.writelines('0\n')
            else:
                zonestr = ''
                for i in range(1,nzones):
                    zonestr += (device_dict[id][i] + ' ')
                outputfile.writelines('%s %s\n' % (ztype, nzones))
                outputfile.writelines('%s\n' % zonestr)
                
        elif card == "ZROT":            # Rotation around the Z axis
            outputfile.writelines('ZROT\n')
            outputfile.writelines('%s\n' % cardvals[0])
            
        elif card == '':                # Empty string - don't break
            continue
        
        else:						# Unknown Device Type
            throwerror("Unknown Device Type: %s" % card, 0, idx)

outputfile.writelines('EMITL\nEnd of Simulation\n') # Always end with EMITL
outputfile.writelines('STOP\n')

#Clean Up
outputfile.close()