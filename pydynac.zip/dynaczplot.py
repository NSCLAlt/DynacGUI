# -*- coding: utf-8 -*-
"""
dynaczplot.py

Scans "dynac.print" file and produces longitudinal plots.

Usage dynaczplot.py [-f filename default='dynac.print'] 
                    [-s dynac.short filename default='dynac.short']

If dynac.short is present, will scan it for the locations of emittance plots
"""
from PyQt4.uic import loadUiType
from PyQt4 import QtGui
from matplotlib.figure import Figure
from matplotlib import rcParams
from matplotlib import pyplot as plt
from matplotlib import cm as cm
from matplotlib.backends.backend_qt4agg import(
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavigationToolbar)
import numpy as np
import sys
import getopt
import re
import os
from collections import OrderedDict as od

Ui_MainWindow, QMainWindow = loadUiType('dynaczplot.ui')

rcParams.update({'figure.autolayout': True})

class Main(QMainWindow, Ui_MainWindow):
    
    def __init__(self, zData):
        # Code that fires when class is instantiated
        super(Main, self).__init__()
        self.setupUi(self)
        self.selectBox.activated.connect(self.select_plot)
        self.startEdit.editingFinished.connect(self.rescale_z)
        self.endEdit.editingFinished.connect(self.rescale_z)
        self.energyBox.stateChanged.connect(self.show_energy)
        self.particleBox.stateChanged.connect(self.show_particles)
        self.eplotBox.stateChanged.connect(self.show_eplots)
                
        # Setup Figure
        fig = Figure()
        self.ax = fig.add_subplot(111)  # axis for main plot
        self.ax2 = self.ax.twinx()      # axis for energy plot
        self.ax3 = self.ax.twinx()      # axis for particle count
        self.ax4 = self.ax.twinx()      # axis for emittance plot locations
        self.titleLabel.setText('Z-axis Data from %s' % zData['filename'])
        
        # Start with x/y profile plot
        initialData = [['zeros','x','y','zeros','zeros'],
                       [1,1,-1,1,1], ['k--','r-','g-','k--','k--']]
        self.lineList = []
        for ds, pm, ls in zip(initialData[0], initialData[1], initialData[2]):
            h, = self.ax.plot(zData['z'],int(pm)*zData[ds],ls)
            self.lineList.append(h)       
        self.ax.set_ylabel('1 RMS Half Width [mm]')
        
        # Add energy plot
        self.eline, = self.ax2.plot(zData['z'], zData['energy'], color='purple',
                         linestyle = '-')
        self.ax2.set_ylabel('Energy [MeV]', color='purple')
        self.ax2.tick_params(axis = 'y', colors = 'purple')
        
        # Add particle plot
        self.pline, = self.ax3.plot(zData['z'], zData['particles'], 
                        color = 'blue', linestyle = '-')
        self.ax3.get_yaxis().set_visible(False)
        particletext = '%g / %g Particles Remaining' % (
            zData['particles'][-1],zData['particles'][0])
        self.ptext = self.ax3.text(0.01, 0.01, particletext,
                                        transform = self.ax3.transAxes)

        # Add emittance plot locatinos
        self.emplotDict = od()
        self.emplotDict = self.ds_scan()

        # Common properties and draw plot
        self.ax.set_xlabel('Position [m]')
        self.canvas = FigureCanvas(fig)
        self.graphPane.addWidget(self.canvas)
        self.canvas.draw()
        
        # Retrieve plot size to feed to limit boxes
        self.zlim = self.ax.get_xlim()
        self.startEdit.setText(str(self.zlim[0]))
        self.endEdit.setText(str(self.zlim[1]))

        
    def ds_scan(self):
        # Scan 'dynac short' for plot locations (later, element positions)
        if not os.path.isfile(dsfile):
            self.statusbar.showMessage('Dynac.short not found, no plot locations')
            self.eplotBox.setEnabled(False)
            return {}
        zpattern = "^\s+(\d+\.\d+)\smm"
        plotpattern = "beam \(emit card\)"
        lastline = ""
        lastpos = 0
        emplotDict = od()
        
        with open(dsfile) as ds:
            line = ds.readline()
            while line:
                result = re.search(plotpattern, line)
                if (result and not (lastpos == 0) and not (lastline=="")
                    and lastline.find('Cavity')==-1):
                    emplotDict[lastline] = [float(lastpos)/1000., 0, 0]
                result = re.match(zpattern, line)
                if result:
                    lastpos = result.group(1)
                lastline = line.strip()
                line = ds.readline()
            
        for ep in emplotDict.keys():
            #[1] = handle to line, [2] = handle to text
            emplotDict[ep][1], = self.ax4.plot(
                (emplotDict[ep][0],emplotDict[ep][0]),(0,1),'k-')
            emplotDict[ep][2] = self.ax4.text(emplotDict[ep][0], 0.97,
                ep, rotation = 90, horizontalalignment = 'right')
            emplotDict[ep][1].set_visible(self.eplotBox.isChecked())
            emplotDict[ep][2].set_visible(self.eplotBox.isChecked())
                
        self.ax4.get_yaxis().set_visible(False)
        return emplotDict
            
        
    def show_energy(self):
        self.eline.set_visible(self.energyBox.isChecked())
        self.ax2.get_yaxis().set_visible(self.energyBox.isChecked())
        self.canvas.draw()
        
    def show_eplots(self):
        for ep in self.emplotDict.keys():
            self.emplotDict[ep][1].set_visible(self.eplotBox.isChecked())
            self.emplotDict[ep][2].set_visible(self.eplotBox.isChecked())
        self.canvas.draw()

    def show_particles(self):
        self.pline.set_visible(self.particleBox.isChecked())
        self.ptext.set_visible(self.particleBox.isChecked())
        self.canvas.draw()
        
    def rescale_z(self):
        start = float(self.startEdit.text())
        end = float(self.endEdit.text())
        
        if (start > self.zlim[1]) or (start < self.zlim[0]):
            start = self.zlim[0]
        if (end > self.zlim[1]) or (end < self.zlim[0]):
            end = self.zlim[1]
        if start > end:
            start = self.zlim[0]
            end = self.zlim[1]
            
        self.startEdit.setText(str(start))
        self.endEdit.setText(str(end))
        self.ax.set_xlim(start,end)
        self.ax.relim()
        self.canvas.draw()
        
    def select_plot(self):
        item = int(self.selectBox.currentIndex())
            
        if item == 0:               # X / Y Profile Graph
            data = [['zeros','x','y','zeros','zeros'],
                    [1,1,-1,1,1],['k','r','g','k','k']]
            label = '1 RMS Half Width[mm]'
        elif item == 1:             # X / Y Emittance Plot
            data = [['zeros','emx','emy','zeros','zeros'],
                    [1,1,-1,1,1],['k','r','g','k','k']]
            label = 'X / Y Emittance [mm.mrad - 1 RMS Normalized'
        elif item == 2:             # Z Emittance Plot
            data = [['zeros', 'emz', 'zeros', 'zeros', 'zeros'],
                    [1,1,1,1,1],['k', 'k', 'k', 'k', 'k']]
            label = 'Z Emittance [keV.ns - 4 RMS]'
        elif item == 3:             # X Envelope Plot
            data = [['zeros', 'xmax', 'xmin', 'x', 'x'],
                    [1,1,1,1,-1],['k', 'r', 'r', 'r', 'r']]
            label = 'X Envelope [mm]'
        elif item == 4:             # Y Envelope Plot
            data = [['zeros', 'ymax', 'ymin', 'y', 'y'],
                    [1,1,1,1,-1],['k', 'g', 'g', 'g', 'g']]
            label = 'Y Envelope [mm]'
        elif item == 5:             # Time Spread
            data = [['zeros', 'deltat', 'zeros', 'zeros', 'zeros'],
                    [1,1,1,1,1],['k', 'k', 'k', 'k', 'k']]
            label = 'Time Spread [ns]'
        elif item == 6:             # Energy Spread
            data = [['zeros', 'deltae', 'zeros', 'zeros', 'zeros'],
                    [1,1,1,1,1],['k', 'k', 'k', 'k', 'k']]
            label = 'Energy Spread [MeV]'
        elif item == 7:             # X Dispersion
            data = [['zeros','Dx','zeros','x','zeros'],
                    [1,1,-1,1,-1],['k','r','w','r','k']]
            label = 'X / (dp / p) [m]'
        elif item == 8:             # Y Dispersion
            data = [['zeros','Dy','zeros','y','zeros'],
                    [1,1,-1,1,-1],['k','g','w','g','k']]
            label = 'X / (dp / p) [m]'
        else:                       # No lines
            data = [['zeros','zeros','zeros','zeros','zeros'],
                    [1,1,1,1,1],['k','w','w','k','k']]
            label = ''
            
        for line, ds, pm, c in zip(self.lineList, data[0], data[1], data[2]):
            line.set_ydata(int(pm)*zData[ds])
            line.set_color(c)
        self.ax.set_ylabel(label)
        
        self.ax.relim()
        self.ax.autoscale()
        self.canvas.draw()
                
        
    def closeEvent(self, event): # Solves crash on exit
        if __name__== '__main__':
            exit()

def readZdata(dpfile):
    if not os.path.isfile(dpfile): # Test for presence of input file
        print 'Error: %s not found.\n' % dpfile
        quit()
    
    zData={}
    zData['filename'] = dpfile
    
    rawData = np.loadtxt(dpfile, skiprows=1)
    zData['z'] = rawData[:,0]
    zData['x'] = rawData[:,1]
    zData['y'] = rawData[:,2]
    zData['emx'] = rawData[:,5]
    zData['emy'] = rawData[:,6]
    zData['emz'] = rawData[:,7]     # keV.ns
    zData['energy'] = rawData[:,8]
    zData['particles'] = rawData[:,9]
    zData['xmin'] = rawData[:,10]
    zData['xmax'] = rawData[:,11]
    zData['ymin'] = rawData[:,12]
    zData['ymax'] = rawData[:,13]
    zData['tmin'] = rawData[:,14]   # s
    zData['tmax'] = rawData[:,15]
    zData['phmin'] = rawData[:,16]  # deg
    zData['phmax'] = rawData[:,17]
    zData['emin'] = rawData[:,18]   # MeV
    zData['emax'] = rawData[:,19]
    zData['Dx'] = rawData[:,20]     # m
    zData['Dy'] = rawData[:,21]
    
    # Derived Series
    zData['zeros'] = np.zeros(len(zData['x']))
    zData['deltat'] = np.subtract(zData['tmax'],zData['tmin']) * 1e9
    zData['deltae'] = np.subtract(zData['emax'],zData['emin'])
    
    return zData    

if __name__ == '__main__':
    # Code that executes if this script is called directly
    dpfile = 'dynac.print'          # Default dynac.print file
    dsfile = 'dynac.short'
    
    # Process command line options
    options, remainder = getopt.getopt(sys.argv[1:], 'f:s:')
    for opt, arg in options:
        if opt in '-f':             # Input file name
            dpfile = arg
        if opt in '-s':
            dsfile = arg
  
    app = QtGui.QApplication(sys.argv)
    zData = readZdata(dpfile)
    main = Main(zData)
    main.show()
    sys.exit(app.exec_())
