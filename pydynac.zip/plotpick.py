# -*- coding: utf-8 -*-
"""
plotpick.py

Scans a Dynac generated *.plot output file and presents a list of the contained
plots.  Allows the user to select a plot and display it using emitplot.py. User
can also select a different filename than the default "emit.plot".

Requires: plotpick.ui, emitplot.py, emitplot.ui
"""
from PyQt4.uic import loadUiType
from PyQt4 import QtGui
from matplotlib.backends.backend_qt4agg import(
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavigationToolbar)
import re
import sys
import os
import emitplot
from collections import OrderedDict as od

Ui_MainWindow, QMainWindow = loadUiType('plotpick.ui')

class Main(QMainWindow, Ui_MainWindow):
    
    def __init__(self):
        super(Main, self).__init__()
        self.setupUi(self)
        self.plotfilename = self.fileLabel.text()
        self.dsfile = self.dsfileLabel.text()
        self.plotlist = od()
        if os.path.isfile(self.plotfilename):
           self.scanFile() 
        else:
           pass
              
        self.show()
        
        self.fileButton.clicked.connect(self.selectFile)
        self.dsfileButton.clicked.connect(self.selectdsFile)
   
    def scanFile(self):
        # Scan the input file for plots, put the list in the dialog box 
        self.plotfilename = self.fileLabel.text()
        self.plotlist.clear()
        try: # Clear connections if they exist
            self.listWidget.itemClicked.disconnect()
        except TypeError:
            pass
            
        pattern = "\s+([1,3-6])\s"
        
        with open(self.plotfilename) as plotfile:
            position = plotfile.tell()
            line = plotfile.readline()
            while line:
                result = re.match(pattern, line)
                if result and result.group(1) == '6': # must be first
                    plotfile.readline()
                    plotfile.readline()
                    self.plotlist[plotfile.readline().strip()] = [ 
                        result.group(1), position]
                elif result and result.group(1) in ['1','3','4','5']:
                    self.plotlist[plotfile.readline().strip()] = [
                        result.group(1), position]
                position = plotfile.tell()
                line = plotfile.readline()
        
        self.listWidget.clear()
        self.listWidget.addItems(self.plotlist.keys())
        self.listWidget.itemClicked.connect(self.itemSelected)

    def selectFile(self):
        plotfilename = QtGui.QFileDialog.getOpenFileName()
        if plotfilename:
            self.fileLabel.setText(plotfile)
            self.scanFile()
       
    def selectdsFile(self):
        dsfilename=QtGui.QFileDialog.getOpenFileName()
        if dsfilename:
            self.dsfileLabel.setText(dsfilename)       
            self.scanFile()
   
    def itemSelected(self, item):
        startpos = self.plotlist[str(item.text())][1]
        dsfile = self.dsfileLabel.text()
        plotfilename = self.fileLabel.text()
        plotData = emitplot.readPlotData(plotfilename, startpos, dsfile)
        self.window = emitplot.plotGraph(plotData)
        
    def closeEvent(self, event):
        exit()
        
if __name__ == '__main__':         
    app = QtGui.QApplication(sys.argv)
    main = Main()
    sys.exit(app.exec_())
